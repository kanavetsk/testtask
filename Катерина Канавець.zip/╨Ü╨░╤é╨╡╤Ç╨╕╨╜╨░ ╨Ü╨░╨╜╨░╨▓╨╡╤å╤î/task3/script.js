document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("searchInput");
    const searchButton = document.getElementById("searchButton");
    const resetButton = document.getElementById("resetButton");
    const resultsTable = document.querySelector("#resultsTable tbody");
    const selectedCount = document.getElementById("selectedCount");
    let selectedCheckboxCount = 0;

    // Восстановление состояния из localStorage
    if (localStorage.getItem("searchResults")) {
        resultsTable.innerHTML = localStorage.getItem("searchResults");
        // Подсчет выбранных чекбоксов
        const checkboxes = document.querySelectorAll("#resultsTable input[type='checkbox']");
        selectedCheckboxCount = Array.from(checkboxes).filter(checkbox => checkbox.checked).length;
    }

    function updateSelectedCount() {
        selectedCount.textContent = `Количество выбранных: ${selectedCheckboxCount}`;
    }

    // Обработчик клика на чекбокс "Сохранить в мой список"
    function handleCheckboxClick(event) {
        const website = event.target.dataset.website;
        if (event.target.checked) {
            selectedCheckboxCount++;
        } else {
            selectedCheckboxCount--;
        }
        updateSelectedCount();
    }

    searchButton.addEventListener("click", function () {
        const searchTerm = searchInput.value.trim();
        if (searchTerm) {
            // Очистить предыдущие результаты
            resultsTable.innerHTML = "";

            // Запрос к API
            fetch(`http://universities.hipolabs.com/search?name=${searchTerm}`)
                .then((response) => response.json())
                .then((data) => {
                    if (data.length > 0) {
                        data.forEach((university, index) => {
                            const universityName = university.name;
                            const country = university.country;
                            const website = university.web_pages[0];
                            const row = document.createElement("tr");
                            const checkboxCell = document.createElement("td");
                            const checkbox = document.createElement("input");
                            checkbox.type = "checkbox";
                            checkbox.dataset.website = website;
                            checkbox.checked = false; // Сбросить состояние чекбокса
                            checkbox.addEventListener("change", handleCheckboxClick);
                            checkboxCell.appendChild(checkbox);

                            row.innerHTML = `
                                <td>${index + 1}</td>
                                <td>${universityName}</td>
                                <td>${country}</td>
                                <td><a href="${website}" target="_blank">${website}</a></td>
                            `;
                            row.appendChild(checkboxCell);
                            resultsTable.appendChild(row);
                        });
                        // Сохранение результатов поиска в localStorage
                        localStorage.setItem("searchResults", resultsTable.innerHTML);
                    } else {
                        const row = document.createElement("tr");
                        row.innerHTML = "<td colspan='5'>Университеты не найдены.</td>";
                        resultsTable.appendChild(row);
                    }
                })
                .catch((error) => {
                    console.error("Ошибка запроса к API:", error);
                });
        }
    });

    resetButton.addEventListener("click", function () {
        searchInput.value = "";
        resultsTable.innerHTML = "";
        selectedCheckboxCount = 0;
        updateSelectedCount();
        // Очистка localStorage при сбросе
        localStorage.removeItem("searchResults");
    });

    // Инициализация счетчика при загрузке страницы
    updateSelectedCount();
});

